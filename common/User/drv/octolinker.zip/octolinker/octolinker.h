/**
 * @file    octolinker.h
 * @author  kaiser
 * @version V1.0.0
 * @date    2026-05-27
 * @brief   OctoLink Binary V1 协议驱动
 *
 * 功能:
 *   - 基于OctoLink Binary V1协议通过UART发送调试数据
 *   - 支持scalar / array / matrix / raw多种数据类型
 *   - 提供line_kv文本调试接口, 方便快速验证
 *   - 阻塞发送模式, 不使用malloc
 *   - 适合STM32CubeMX / HAL工程
 *
 * 与VOFA+的区别:
 *   - VOFA+ JustFloat: 多float + NaN帧尾, 仅支持float通道
 *   - OctoLink Binary: varId + type + shape + payload + crc, 可表达多种数据类型
 *   - OctoLink支持scalar / array / matrix / raw
 *   - line_kv模式用于人工调试, binary模式用于Dashboard自动绑定
 *
 * 使用示例:
 *   Octolinker_Instance_t octo;
 *   Octolinker_Init(&octo, &huart1);
 *
 *   // Binary模式
 *   Octolinker_SendF32(&octo, 1, ins_data.yaw);
 *   Octolinker_SendF32(&octo, 2, ins_data.roll);
 *   Octolinker_SendF32(&octo, 3, ins_data.pitch);
 *   Octolinker_SendU32(&octo, 4, HAL_GetTick());
 *
 *   // line_kv模式
 *   Octolinker_SendKV_F32(&octo, "yaw", ins_data.yaw);
 *   Octolinker_SendKV_F32(&octo, "roll", ins_data.roll);
 */

#ifndef OCTOLINKER_H
#define OCTOLINKER_H

#include <stdint.h>
#include <stddef.h>
#include "usart.h"

/* ==================== 协议常量 ==================== */

#define OCTOLINKER_VERSION          1       /**< 协议版本号 */
#define OCTOLINKER_SOF0             0xA5    /**< 帧头字节0 */
#define OCTOLINKER_SOF1             0x5A    /**< 帧头字节1 */
#define OCTOLINKER_MAX_PAYLOAD      128     /**< 最大payload长度 */
#define OCTOLINKER_MAX_SHAPE_DIMS   4       /**< 最大shape维度数 */
#define OCTOLINKER_TX_TIMEOUT_MS    2       /**< 发送超时(ms) */

/* ==================== valueType定义 ==================== */

#define OCTOLINKER_TYPE_I32         1       /**< int32_t */
#define OCTOLINKER_TYPE_U32         2       /**< uint32_t */
#define OCTOLINKER_TYPE_F32         3       /**< float */
#define OCTOLINKER_TYPE_I16         4       /**< int16_t */
#define OCTOLINKER_TYPE_U16         5       /**< uint16_t */
#define OCTOLINKER_TYPE_I8          6       /**< int8_t */
#define OCTOLINKER_TYPE_U8          7       /**< uint8_t */
#define OCTOLINKER_TYPE_RAW         8       /**< 原始字节 */
#define OCTOLINKER_TYPE_F32_ARRAY   9       /**< float数组 */
#define OCTOLINKER_TYPE_U16_ARRAY   10      /**< uint16_t数组 */
#define OCTOLINKER_TYPE_U8_MATRIX   11      /**< uint8_t矩阵 */

/* ==================== 数据类型定义 ==================== */

/**
 * @brief OctoLink实例结构体
 * @note  tx_buf预分配, 避免动态内存分配
 */
typedef struct {
    UART_HandleTypeDef *huart;  /**< UART句柄 */
    uint8_t tx_buf[2 + 1 + 2 + 1 + 1 + OCTOLINKER_MAX_SHAPE_DIMS + 2 + OCTOLINKER_MAX_PAYLOAD + 1]; /**< 发送缓冲区 */
    uint16_t tx_len;            /**< 当前发送长度 */
} Octolinker_Instance_t;

/* ==================== 初始化函数 ==================== */

/**
 * @brief  初始化OctoLink实例
 * @param  ol    实例指针
 * @param  huart UART句柄
 */
void Octolinker_Init(Octolinker_Instance_t *ol, UART_HandleTypeDef *huart);

/* ==================== Binary协议发送函数 ==================== */

/**
 * @brief  发送原始数据帧
 * @param  ol         实例指针
 * @param  var_id     变量ID
 * @param  value_type 数据类型 (OCTOLINKER_TYPE_xxx)
 * @param  shape      shape数组指针 (可为NULL)
 * @param  shape_len  shape维度数 (0~OCTOLINKER_MAX_SHAPE_DIMS)
 * @param  payload    payload数据指针
 * @param  payload_len payload长度
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendFrame(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    uint8_t value_type,
    const uint8_t *shape,
    uint8_t shape_len,
    const uint8_t *payload,
    uint16_t payload_len
);

/**
 * @brief  发送float数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  float值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendF32(Octolinker_Instance_t *ol, uint16_t var_id, float value);

/**
 * @brief  发送int32_t数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  int32_t值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendI32(Octolinker_Instance_t *ol, uint16_t var_id, int32_t value);

/**
 * @brief  发送uint32_t数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  uint32_t值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendU32(Octolinker_Instance_t *ol, uint16_t var_id, uint32_t value);

/**
 * @brief  发送int16_t数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  int16_t值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendI16(Octolinker_Instance_t *ol, uint16_t var_id, int16_t value);

/**
 * @brief  发送uint16_t数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  uint16_t值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendU16(Octolinker_Instance_t *ol, uint16_t var_id, uint16_t value);

/**
 * @brief  发送int8_t数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  int8_t值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendI8(Octolinker_Instance_t *ol, uint16_t var_id, int8_t value);

/**
 * @brief  发送uint8_t数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  value  uint8_t值
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendU8(Octolinker_Instance_t *ol, uint16_t var_id, uint8_t value);

/**
 * @brief  发送float数组
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  values float数组指针
 * @param  count  数组元素个数
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendF32Array(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const float *values,
    uint8_t count
);

/**
 * @brief  发送uint16_t数组
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  values uint16_t数组指针
 * @param  count  数组元素个数
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendU16Array(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const uint16_t *values,
    uint8_t count
);

/**
 * @brief  发送uint8_t矩阵
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  values uint8_t矩阵数据指针
 * @param  rows   行数
 * @param  cols   列数
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendU8Matrix(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const uint8_t *values,
    uint8_t rows,
    uint8_t cols
);

/**
 * @brief  发送原始字节数据
 * @param  ol     实例指针
 * @param  var_id 变量ID
 * @param  data   数据指针
 * @param  len    数据长度
 * @return HAL_StatusTypeDef
 */
HAL_StatusTypeDef Octolinker_SendRaw(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const uint8_t *data,
    uint16_t len
);

/* ==================== 文本调试接口 ==================== */

/**
 * @brief  发送一行文本 (line_kv模式)
 * @param  ol   实例指针
 * @param  line 文本字符串
 * @return HAL_StatusTypeDef
 * @note   自动追加\r\n (如果没有换行符)
 */
HAL_StatusTypeDef Octolinker_PrintLine(Octolinker_Instance_t *ol, const char *line);

/**
 * @brief  发送key=value格式的float值
 * @param  ol    实例指针
 * @param  key   键名
 * @param  value float值
 * @return HAL_StatusTypeDef
 * @note   输出格式: key=value\r\n
 */
HAL_StatusTypeDef Octolinker_SendKV_F32(Octolinker_Instance_t *ol, const char *key, float value);

/**
 * @brief  发送key=value格式的int32_t值
 * @param  ol    实例指针
 * @param  key   键名
 * @param  value int32_t值
 * @return HAL_StatusTypeDef
 * @note   输出格式: key=value\r\n
 */
HAL_StatusTypeDef Octolinker_SendKV_I32(Octolinker_Instance_t *ol, const char *key, int32_t value);

/**
 * @brief  发送key=value格式的uint32_t值
 * @param  ol    实例指针
 * @param  key   键名
 * @param  value uint32_t值
 * @return HAL_StatusTypeDef
 * @note   输出格式: key=value\r\n
 */
HAL_StatusTypeDef Octolinker_SendKV_U32(Octolinker_Instance_t *ol, const char *key, uint32_t value);

#endif /* OCTOLINKER_H */
