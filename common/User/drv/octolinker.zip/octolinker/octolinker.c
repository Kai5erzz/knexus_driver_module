/**
 * @file    octolinker.c
 * @author  kaiser
 * @version V1.0.0
 * @date    2026-05-27
 * @brief   OctoLink Binary V1 协议驱动实现
 *
 * 协议格式:
 *   [0xA5][0x5A][version][varId_L][varId_H][valueType][shapeLen][shape...][payloadLen_L][payloadLen_H][payload...][crc8]
 *
 * CRC8计算:
 *   从version字节开始XOR到payload最后一个字节, 不包含帧头和crc自身
 */

#include "octolinker.h"
#include <string.h>
#include <stdio.h>

/* ==================== 内部函数 ==================== */

/**
 * @brief  计算CRC8 (XOR方式)
 * @param  data 数据指针
 * @param  len  数据长度
 * @return CRC8值
 */
static uint8_t Octolinker_CalcCRC8(const uint8_t *data, uint16_t len)
{
    uint8_t crc = 0;
    for (uint16_t i = 0; i < len; i++) {
        crc ^= data[i];
    }
    return crc;
}

/* ==================== 初始化函数 ==================== */

void Octolinker_Init(Octolinker_Instance_t *ol, UART_HandleTypeDef *huart)
{
    if (ol == NULL) return;

    ol->huart = huart;
    memset(ol->tx_buf, 0, sizeof(ol->tx_buf));
    ol->tx_len = 0;
}

/* ==================== Binary协议发送函数 ==================== */

HAL_StatusTypeDef Octolinker_SendFrame(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    uint8_t value_type,
    const uint8_t *shape,
    uint8_t shape_len,
    const uint8_t *payload,
    uint16_t payload_len)
{
    if (ol == NULL || ol->huart == NULL || payload == NULL) {
        return HAL_ERROR;
    }

    if (shape_len > OCTOLINKER_MAX_SHAPE_DIMS) {
        return HAL_ERROR;
    }

    if (payload_len > OCTOLINKER_MAX_PAYLOAD) {
        return HAL_ERROR;
    }

    uint16_t pos = 0;

    /* 帧头 */
    ol->tx_buf[pos++] = OCTOLINKER_SOF0;
    ol->tx_buf[pos++] = OCTOLINKER_SOF1;

    /* version */
    ol->tx_buf[pos++] = OCTOLINKER_VERSION;

    /* varId (little-endian) */
    ol->tx_buf[pos++] = (uint8_t)(var_id & 0xFF);
    ol->tx_buf[pos++] = (uint8_t)((var_id >> 8) & 0xFF);

    /* valueType */
    ol->tx_buf[pos++] = value_type;

    /* shapeLen */
    ol->tx_buf[pos++] = shape_len;

    /* shape */
    for (uint8_t i = 0; i < shape_len; i++) {
        ol->tx_buf[pos++] = shape[i];
    }

    /* payloadLen (little-endian) */
    ol->tx_buf[pos++] = (uint8_t)(payload_len & 0xFF);
    ol->tx_buf[pos++] = (uint8_t)((payload_len >> 8) & 0xFF);

    /* payload */
    memcpy(&ol->tx_buf[pos], payload, payload_len);
    pos += payload_len;

    /* CRC8: 从version字节开始XOR到payload结束 */
    uint8_t crc = Octolinker_CalcCRC8(&ol->tx_buf[2], pos - 2);
    ol->tx_buf[pos++] = crc;

    ol->tx_len = pos;

    return HAL_UART_Transmit(ol->huart, ol->tx_buf, ol->tx_len, OCTOLINKER_TX_TIMEOUT_MS);
}

HAL_StatusTypeDef Octolinker_SendF32(Octolinker_Instance_t *ol, uint16_t var_id, float value)
{
    uint8_t payload[4];
    memcpy(payload, &value, sizeof(float));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_F32, NULL, 0, payload, sizeof(float));
}

HAL_StatusTypeDef Octolinker_SendI32(Octolinker_Instance_t *ol, uint16_t var_id, int32_t value)
{
    uint8_t payload[4];
    memcpy(payload, &value, sizeof(int32_t));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_I32, NULL, 0, payload, sizeof(int32_t));
}

HAL_StatusTypeDef Octolinker_SendU32(Octolinker_Instance_t *ol, uint16_t var_id, uint32_t value)
{
    uint8_t payload[4];
    memcpy(payload, &value, sizeof(uint32_t));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_U32, NULL, 0, payload, sizeof(uint32_t));
}

HAL_StatusTypeDef Octolinker_SendI16(Octolinker_Instance_t *ol, uint16_t var_id, int16_t value)
{
    uint8_t payload[2];
    memcpy(payload, &value, sizeof(int16_t));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_I16, NULL, 0, payload, sizeof(int16_t));
}

HAL_StatusTypeDef Octolinker_SendU16(Octolinker_Instance_t *ol, uint16_t var_id, uint16_t value)
{
    uint8_t payload[2];
    memcpy(payload, &value, sizeof(uint16_t));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_U16, NULL, 0, payload, sizeof(uint16_t));
}

HAL_StatusTypeDef Octolinker_SendI8(Octolinker_Instance_t *ol, uint16_t var_id, int8_t value)
{
    uint8_t payload[1];
    memcpy(payload, &value, sizeof(int8_t));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_I8, NULL, 0, payload, sizeof(int8_t));
}

HAL_StatusTypeDef Octolinker_SendU8(Octolinker_Instance_t *ol, uint16_t var_id, uint8_t value)
{
    uint8_t payload[1];
    memcpy(payload, &value, sizeof(uint8_t));
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_U8, NULL, 0, payload, sizeof(uint8_t));
}

HAL_StatusTypeDef Octolinker_SendF32Array(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const float *values,
    uint8_t count)
{
    if (values == NULL || count == 0) {
        return HAL_ERROR;
    }

    uint16_t payload_len = count * sizeof(float);
    if (payload_len > OCTOLINKER_MAX_PAYLOAD) {
        return HAL_ERROR;
    }

    uint8_t shape[1] = {count};
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_F32_ARRAY, shape, 1, (const uint8_t *)values, payload_len);
}

HAL_StatusTypeDef Octolinker_SendU16Array(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const uint16_t *values,
    uint8_t count)
{
    if (values == NULL || count == 0) {
        return HAL_ERROR;
    }

    uint16_t payload_len = count * sizeof(uint16_t);
    if (payload_len > OCTOLINKER_MAX_PAYLOAD) {
        return HAL_ERROR;
    }

    uint8_t shape[1] = {count};
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_U16_ARRAY, shape, 1, (const uint8_t *)values, payload_len);
}

HAL_StatusTypeDef Octolinker_SendU8Matrix(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const uint8_t *values,
    uint8_t rows,
    uint8_t cols)
{
    if (values == NULL || rows == 0 || cols == 0) {
        return HAL_ERROR;
    }

    uint16_t payload_len = rows * cols;
    if (payload_len > OCTOLINKER_MAX_PAYLOAD) {
        return HAL_ERROR;
    }

    uint8_t shape[2] = {rows, cols};
    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_U8_MATRIX, shape, 2, values, payload_len);
}

HAL_StatusTypeDef Octolinker_SendRaw(
    Octolinker_Instance_t *ol,
    uint16_t var_id,
    const uint8_t *data,
    uint16_t len)
{
    if (data == NULL || len == 0) {
        return HAL_ERROR;
    }

    if (len > OCTOLINKER_MAX_PAYLOAD) {
        return HAL_ERROR;
    }

    return Octolinker_SendFrame(ol, var_id, OCTOLINKER_TYPE_RAW, NULL, 0, data, len);
}

/* ==================== 文本调试接口 ==================== */

HAL_StatusTypeDef Octolinker_PrintLine(Octolinker_Instance_t *ol, const char *line)
{
    if (ol == NULL || ol->huart == NULL || line == NULL) {
        return HAL_ERROR;
    }

    char buf[128];
    size_t len = strlen(line);

    /* 检查是否有换行符 */
    if (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r')) {
        /* 已有换行符, 直接发送 */
        if (len >= sizeof(buf)) {
            len = sizeof(buf) - 1;
        }
        memcpy(buf, line, len);
        buf[len] = '\0';
    } else {
        /* 追加\r\n */
        if (len >= sizeof(buf) - 2) {
            len = sizeof(buf) - 3;
        }
        memcpy(buf, line, len);
        buf[len++] = '\r';
        buf[len++] = '\n';
        buf[len] = '\0';
    }

    return HAL_UART_Transmit(ol->huart, (uint8_t *)buf, (uint16_t)len, OCTOLINKER_TX_TIMEOUT_MS);
}

HAL_StatusTypeDef Octolinker_SendKV_F32(Octolinker_Instance_t *ol, const char *key, float value)
{
    if (ol == NULL || ol->huart == NULL || key == NULL) {
        return HAL_ERROR;
    }

    char buf[64];
    int len = snprintf(buf, sizeof(buf), "%s=%.3f\r\n", key, (double)value);
    if (len < 0 || (size_t)len >= sizeof(buf)) {
        return HAL_ERROR;
    }

    return HAL_UART_Transmit(ol->huart, (uint8_t *)buf, (uint16_t)len, OCTOLINKER_TX_TIMEOUT_MS);
}

HAL_StatusTypeDef Octolinker_SendKV_I32(Octolinker_Instance_t *ol, const char *key, int32_t value)
{
    if (ol == NULL || ol->huart == NULL || key == NULL) {
        return HAL_ERROR;
    }

    char buf[48];
    int len = snprintf(buf, sizeof(buf), "%s=%ld\r\n", key, (long)value);
    if (len < 0 || (size_t)len >= sizeof(buf)) {
        return HAL_ERROR;
    }

    return HAL_UART_Transmit(ol->huart, (uint8_t *)buf, (uint16_t)len, OCTOLINKER_TX_TIMEOUT_MS);
}

HAL_StatusTypeDef Octolinker_SendKV_U32(Octolinker_Instance_t *ol, const char *key, uint32_t value)
{
    if (ol == NULL || ol->huart == NULL || key == NULL) {
        return HAL_ERROR;
    }

    char buf[48];
    int len = snprintf(buf, sizeof(buf), "%s=%lu\r\n", key, (unsigned long)value);
    if (len < 0 || (size_t)len >= sizeof(buf)) {
        return HAL_ERROR;
    }

    return HAL_UART_Transmit(ol->huart, (uint8_t *)buf, (uint16_t)len, OCTOLINKER_TX_TIMEOUT_MS);
}
